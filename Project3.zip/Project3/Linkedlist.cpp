#include "Linkedlist.h"

Linkedlist::Linkedlist()
{
	this->head = nullptr;
	this->tail = nullptr;
}

Linkedlist::~Linkedlist()
{
}

void Linkedlist::addHead(Element* a)
{
	if (this->head == nullptr) {
		this->head = this->tail = a;
	}
	else {
		a->setPointer(this->head);
		this->head = a;
	}
}

void Linkedlist::display()
{
	Element* p = this->head;
	while (p != nullptr) {
		std::cout << p->getData() << " ";
		p = p->getPointer();
	}
}
