#pragma once
#include"Element.h"
#include<iostream>
class Linkedlist
{
private:
	Element* head;
	Element* tail;

public:
	Linkedlist();
	~Linkedlist();
	void addHead(Element*);
	void display();
};

