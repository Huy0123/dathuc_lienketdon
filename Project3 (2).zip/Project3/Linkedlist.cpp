﻿#include "Linkedlist.h"

Linkedlist::Linkedlist()
{
	this->head = nullptr;
	this->tail = nullptr;
}

Linkedlist::~Linkedlist()
{
}

void Linkedlist::addHead(Element* a)
{
	if (this->head == nullptr) {
		this->head = this->tail = a;
	}
	else {
		a->setPointer(this->head);
		this->head = a;
	}
}

void Linkedlist::display()
{
	Element* p = this->head;
	while (p != nullptr) {
		std::cout << p->getData() << " ";
		p = p->getPointer();
	}
}

int Linkedlist::Sumlist()
{
	Element* p = this->head;
	int sum=0;
	while (p != nullptr) {
		sum += p->getData();
		p = p->getPointer();
	}
	return sum;
}

int Linkedlist::Maxlist()
{
	Element* p = this->head;
	int max = 0;
	while (p != nullptr) {
		if (p->getData() > max) {
			max = p->getData();
		}
		p = p->getPointer();
	}
	return max;
}

int Linkedlist::Countlist()
{
	Element* p = this->head;
	int count = 0;
	while (p != nullptr) {
		count++;
		p = p->getPointer();
	}
	return count;
}

void Linkedlist::addTail(Element* a)
{
	if (this->head == nullptr) {
		this->head = this->tail = a;
	}
	else{
		this->tail->setPointer(a);
		this->tail = a;
	}
}

void Linkedlist::DeleteHead()
{
	Element* p = head;
	this->head = this->head->getPointer();
	delete p;
}

void Linkedlist::DeleteTail()
{
	Element* p = head;
	while (p->getPointer()!=tail)
	{
		p = p->getPointer();
	}
	delete tail;
	tail = p;
	tail->setPointer(nullptr);
}

int Linkedlist::FindX(int x)
{
	Element* p = head;
	int count = 0;
	while (p!=nullptr)
	{
		if (p->getData() == x) {
			count++;
		}
		p = p->getPointer();
	}
	return count;
}

bool Linkedlist::kiemtra_trung(int x)
{
	Element* p = head;
	while (p!=nullptr)
	{
		if (p->getData() == x) {
			return true;
		}
		else return false;
		p = p->getPointer();
	}
}

void Linkedlist::splitLinkedlist(Linkedlist*& a, Linkedlist*& b, int x)
{
	Element* p = head;

	while (p != nullptr) {
		if (p->getData() > x) {
				a->addTail(p);
		}
		else {
				b->addTail(p);
		}

		p = p->getPointer();
	}

	a->tail->setPointer(nullptr);
	b->tail->setPointer(nullptr);
	head = tail = nullptr;
}


