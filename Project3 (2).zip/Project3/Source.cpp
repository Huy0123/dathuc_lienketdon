#include"Element.h"
#include"Linkedlist.h"
#include<iostream>
using namespace std;

int main()
{
    Linkedlist* myList= new Linkedlist();
    Linkedlist* a = new Linkedlist;
    Linkedlist* b = new Linkedlist;
    int n, x;
    cout << "Nhap so lien ket don: ";
    cin >> n;
    cout << "Nhap data: ";
    for (int i = 0; i < n; i++) {
        cin >> x;
        if (!myList->kiemtra_trung(x)) {
            Element* e = new Element();
            e->setData(x);
            myList->addTail(e);
        }
    }
    /*int c;
    cin >> c;
    myList->splitLinkedlist(a, b, c);
    a->display();
    cout << endl;
    b->display();*/
    cout << "danh sach lien ket don: ";
    myList->display();
    delete myList;
    delete a;
    delete b;
	return 0;
}